"""
Filename: main.py
Author: Martin Marusak, m.marusak@mitutoyo.cz
Date: 2025-01-23
Description: Functional demonstration of a minimalist version of the Mitutoyo LSM user interface
             with value display and sort group functionality.

Licence: Free Software
"""


from tkinter import *
import csv
import serial
import configparser
import traceback
from tkinter import messagebox
# import from local python file
from lsm import *    #lsm_init, lsm_get_status, lsm_read_onceRaw, lsm_get_calibration_h, lsm_get_calibration_l


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    COLOR_RED = '#ee0000'
    COLOR_GREEN = '#00ff00'
    COLOR_GREY = '#aaaaaa'
    DEBUG_MODE = True


# -------------------------------------------------------------------------
def callback_delete_window():
    print('QUIT')
    serialOne.close()
    root.quit()
    root.destroy()


# -------------------------------------------------------------------------
def port_is_usable(port_name):
    try:
       ser = serial.Serial(port=port_name)
       return True
    except:
       return False


# -------------------------------------------------------------------------
class DisplayGui:
    def __init__(self, root):
        self.root = root
        self.color = None  # pyCharm: for better readibility
        self.value = None  # pyCharm: for better readibility

        # Labels are create there:
        self.Label1 = Label(root, text="", bg=background_color_OK, font=("Lucida Console", font_size))  # for anchor to left add: , anchor = "w"
        self.Label1.pack(fill=X, ipady=padding_y)
        self.LabelLine = Label(root, text="", font=("Lucida Console", 1))
        self.LabelLine.pack()
        self.Label2 = Label(root, text="", bg=background_color_OK, font=("Lucida Console", font_size))
        self.Label2.pack(fill=X, ipady=padding_y)
        self.Label3 = Label(root, text="", justify = LEFT,  bg=COLOR_GREY, font=("Lucida Console", 12))
        self.Label3.pack(fill=X, ipady=2)

    def set_value_1(self, color, value):
        self.color = color
        self.value = value
        self.Label1.configure(bg=color)
        self.Label1.configure(text=value)

    def set_value_2(self, color, value):
        self.color = color
        self.value = value
        self.Label2.configure(bg = color)
        self.Label2.configure(text = value)

    def set_value_3(self, color, value):
        self.color = color
        self.value = value
        self.Label3.configure(bg = color)
        self.Label3.configure(text = value)


# -------------------------------------------------------------------------
def choose_sorting_group(group_list, value):
    # return string
    sortgroup: str = '►'                         # default + when the max value is exceeded
    if (value < float(group_list[1][0])):
        return '◄'                          # if lower than minimum on list

    # retrieving values and groups from the table
    for i in range (len(group_list)-2):
        print(group_list[i+1][0] +'  ' + group_list[i+2][0] +'  ' + group_list[i+1][1])   # values are from i+1, i = header
        lo_limit: float = float(group_list[i+1][0])
        hi_limit: float = float(group_list[i+2][0])
        if ((value >= lo_limit) and (value < hi_limit)):
            return group_list[i+1][1]

    return sortgroup


# -------------------------------------------------------------------------
def lsm_task():
    # main procedure for retrieving values from the LSM
    print('---------------------- LSM TASK ---')
    try:
        result = lsm_read_onceRaw(serialOne)
        print(result)
        if (result[0:1]) == 'P':
            # for NO ERROR status read value
            lsm_value = result[4:]  # full vale, 5 decimal places
            # find sortin level
            level = choose_sorting_group(sortingLevels, float(lsm_value))
            lsm_value = f'{float(lsm_value):.{decimal_places}f}'  # rounded value as string
        else:
            # for ERROR <> 0 return symbol
            lsm_value = '......'
            level = ''

        infoTable.set_value_1(background_color_OK, level)  # show value on display
        infoTable.set_value_2(background_color_OK, lsm_value)  # show value on display

        root.after(poling_frequency, lsm_task)       # reschedule event for 250 miliseconds
    except Exception as X:
        messagebox.showerror(title="Program error - tracebags", message=traceback.format_exc())
        quit()

# ===============================  M A I N  ===============================
# read data from config.ini file
try:
    config = configparser.ConfigParser()
    config.read('config.ini')

    sorting_level_file = config['Default']['sorting_level_file']
    com_port = config['Default']['com_port']
    poling_frequency = config['Default']['poling_frequency']

    window_x = config['DisplayedGUI']['window_x']
    window_y = config['DisplayedGUI']['window_y']
    window_maximized = config['DisplayedGUI']['maximized']
    padding_y = config['DisplayedGUI']['padding_y']
    font_size = config['DisplayedGUI']['font_size']

    background_color_OK = config['DisplayedGUI']['background_color_OK']
    background_color_NOK = config['DisplayedGUI']['background_color_NOK']

    decimal_places = config['Results']['decimal_places']

except:
    print()
    messagebox.showerror(title="COM port error", message='Konfigurační soubor config.ini nelze otevřít. Aplikace nemůže být spuštěna.')
    quit()

# serial port definition
if port_is_usable(com_port):
    serialOne = serial.Serial(com_port, 9600, timeout=1)
    if serialOne.isOpen() is False:
        serialOne.open()

    try:
        file = open(sorting_level_file, "r")
        sortingLevels = list(csv.reader(file, delimiter=";"))
        file.close()
    except Exception as e:
        print('Nelze otevřít soubor SortingLevels.csv.')
        messagebox.showerror(title="File error", message='Nelze otevřít CSV soubor s limity.')
        quit()

    root = Tk()
    root.protocol("WM_DELETE_WINDOW", callback_delete_window)
    root.title("LSM sorting")
    root.iconbitmap('mitutoyo.ico')
    root.geometry(window_x + 'x' + window_y + '+0+0')
    root.resizable(True, True)
    if window_maximized == "1":
        root.state('zoomed')

    try:
        lsm_init(serialOne)
    except Exception as e:
        print('Nelze otevřít soubor SortingLevels.csv.')
        messagebox.showerror(title="File error", message='Nelze otevřít CSV soubor s limity.')
        quit()

    # create object InfoTable
    infoTable = DisplayGui(root)
    lsm_status_list = lsm_get_status(serialOne)
    infoTable.set_value_3('#aaaaaa', 'Program ' + lsm_status_list[3] + ', averages ' + lsm_status_list[7] + ', Hcalib.: ' + lsm_get_calibration_h(serialOne) + ', Lcalib.: ' + lsm_get_calibration_l(serialOne))

    root.after(poling_frequency, lsm_task)  # schedule first event in 0,5 seconds
    root.mainloop()

else:
    print('Serial port ' + com_port + ' is not usable. Change record in the config.ini file.')
    messagebox.showerror(title="COM port error",
                         message='Sériový port ' + com_port + ' nelze otevřít. Pro změnu portu změňte záznam v souboru config.ini.')