"""
Filename: lsm.py
Author: Martin Marusak, m.marusak@mitutoyo.cz
Date: 2025-01-23
Description: Separate function module for Mitutoyo LSM.

Licence: Free Software
"""


def lsm_init(serialOne):
    # nothing return
    # NOTE: this comand is "mostly used initial sequence". It could be not optimal for specific use.

    # set output condition
    serialOne.write("SCOND,1000,PRC,1\r\n".encode())    # Output condition: enabled, each value
    serial_line_received = serialOne.readline()
    # set output condition
    serialOne.write("SCOND,1000,PRT,1\r\n".encode())    # Output timing: 1 sec after data valid
    serial_line_received = serialOne.readline()


# -------------------------------------------------------------------------
def lsm_get_status(serialOne):
    '''
    Return strings of comma separated string items
    Example or received status (no error): 0STS,1000,A,P00,7.98070,1025,0,1024
    Explanation for comma separated list:
      [0]  command response (0STS)
      [1]  device number (1000)
      [2]  (A)
      [3]  program number (P00)
      [4]  value [mm]
      [5]  status
      [6]  error status (0 = no error)
      [7]  samples count in one measuremnnt
    '''
    serialOne.write("GSTS,1000,A\r\n".encode())    # Output condition: enabled, each value

    serial_line_received = serialOne.readline()
    status = serial_line_received.decode('utf-8').rstrip().split(",")
    return status


# -------------------------------------------------------------------------
def lsm_get_calibration_h(serialOne):
    '''
    Return strings with value of H calibration
    Example: 3.05000
    '''
    serialOne.write("GCAL,1000,H\r\n".encode())
    # example or received status (no error): 0CAL,1000,H,3.05000
    serial_line_received = serialOne.readline()
    response = serial_line_received.decode('utf-8').rstrip()

    if (response[0:1]) == '0':
        # for NO ERROR status in readed response (first chracter is 0)
        return response[12:]
    else:
        raise Exception("LSM bad response by H callibration request. ")


# -------------------------------------------------------------------------
def lsm_get_calibration_l(serialOne):
    '''
    Return strings with value of H calibration
    Example: 0          (by one point calibration)
             1.09500
    '''
    serialOne.write("GCAL,1000,L\r\n".encode())
    # example or received status (no error): 0CAL,1000,L,0.00000
    serial_line_received = serialOne.readline()
    response = serial_line_received.decode('utf-8').rstrip()
    print(response)

    if (response[0:1]) == '0':
        # for NO ERROR status in readed response (first chracter is 0)
        return response[12:]
    else:
        raise Exception("LSM bad response by H callibration request. ")


# -------------------------------------------------------------------------
def lsm_read_onceRaw(serialOne):
    '''
    Return strings with value of H calibration
    Example: P00,7.98055        (without tolerance judgement)
             P00,-NG,7.98055    (with tolerance judgement)
    '''
    serialOne.write("PMEAS,1000,R\r\n".encode())
    serial_line_received = serialOne.readline()  # this string ends with \r\n !!
    response = serial_line_received.decode('utf-8').rstrip()
    return response
